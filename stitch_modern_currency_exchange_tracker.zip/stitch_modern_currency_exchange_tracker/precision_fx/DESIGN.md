---
name: Precision FX
colors:
  surface: '#fbf8ff'
  surface-dim: '#d9d9e6'
  surface-bright: '#fbf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f2ff'
  surface-container: '#ededfb'
  surface-container-high: '#e7e7f5'
  surface-container-highest: '#e1e1ef'
  on-surface: '#191b25'
  on-surface-variant: '#424656'
  inverse-surface: '#2e303a'
  inverse-on-surface: '#f0effd'
  outline: '#727687'
  outline-variant: '#c2c6d8'
  surface-tint: '#0054d6'
  primary: '#0050cc'
  on-primary: '#ffffff'
  primary-container: '#0266ff'
  on-primary-container: '#f8f7ff'
  inverse-primary: '#b3c5ff'
  secondary: '#415c9f'
  on-secondary: '#ffffff'
  secondary-container: '#9ab4fe'
  on-secondary-container: '#284486'
  tertiary: '#a33200'
  on-tertiary: '#ffffff'
  tertiary-container: '#cc4204'
  on-tertiary-container: '#fff6f4'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b3c5ff'
  on-primary-fixed: '#001849'
  on-primary-fixed-variant: '#003fa4'
  secondary-fixed: '#dae2ff'
  secondary-fixed-dim: '#b2c5ff'
  on-secondary-fixed: '#001848'
  on-secondary-fixed-variant: '#274485'
  tertiary-fixed: '#ffdbd0'
  tertiary-fixed-dim: '#ffb59d'
  on-tertiary-fixed: '#390c00'
  on-tertiary-fixed-variant: '#832600'
  background: '#fbf8ff'
  on-background: '#191b25'
  surface-variant: '#e1e1ef'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-sm:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  h1:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  h2:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  numeric-xl:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '500'
    lineHeight: '1'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 40px
  container-max: 1200px
  gutter: 20px
---

## Brand & Style
The design system is engineered to evoke trust, technical precision, and immediate clarity. Targeted at global travelers, digital nomads, and retail investors, the UI prioritizes speed of comprehension and financial transparency.

The aesthetic merges **Corporate Modernism** with **Glassmorphism**. This combination balances the reliability expected of financial institutions with the progressive, high-tech feel of modern fintech. By utilizing semi-transparent surfaces for secondary information and crisp, solid containers for core transactional data, the system creates a multi-layered environment that feels both deep and breathable. The overall emotional response should be one of "effortless control"—where complex currency data is rendered simple and actionable.

## Colors
The palette is centered on a refined technical spectrum that prioritizes legibility and professional tone over high-vibrancy alerts.

- **Primary (Electric Blue):** The primary driver for user flow, used for critical actions and brand markers.
- **Secondary (Steel Indigo):** A muted, professional tone used for supporting interface elements and secondary visual interest.
- **Tertiary (Cinnabar):** A warm, deep orange-red used for specific emphasis and highlighting data trends that require attention.
- **Neutral (Cool Gray):** A balanced gray scale used for borders, secondary text, and UI scaffolding.
- **Surface Palette:** Employs a "Paper-on-Cloud" approach, using pure white for primary cards against a very light neutral-tinted background to provide soft contrast without visual noise.

## Typography
Inter is selected for its exceptional legibility and neutral tone. To support the currency-centric nature of the platform, the design system leverages **tabular figures (tnum)** for all numeric displays. This ensures that columns of numbers and fluctuating exchange rates remain aligned, preventing visual "jumping" during real-time updates.

Hierarchy is established through weight and scale rather than decorative shifts. Display styles are tight and bold for impact, while body text maintains generous line-heights for readability during complex financial comparisons.

## Layout & Spacing
The design system utilizes a **12-column fluid grid** for desktop and a single-column stack for mobile. It follows a strict 4px baseline grid to ensure vertical rhythm across all currency cards and data tables.

- **Margins:** A minimum of 16px on mobile, scaling to 40px on large screens.
- **Gutters:** Fixed at 20px to maintain breathing room between complex data sets.
- **Information Density:** Large white spaces are prioritized to separate different currency pairs, preventing the "wall of numbers" effect common in legacy financial tools.

## Elevation & Depth
Depth is communicated through light and transparency rather than heavy shadows. The system uses three distinct levels:

1.  **Base (0dp):** The neutral-tinted background layer.
2.  **Raised (1dp):** Primary cards with a white fill and a subtle `0px 4px 20px rgba(117, 118, 130, 0.08)` shadow.
3.  **Glass Overlay (2dp):** Used for tooltips, navigation bars, and currency selectors. These elements utilize a backdrop-blur (12px to 20px) and a semi-transparent white fill (`rgba(255, 255, 255, 0.7)`) to create a frosted-glass effect that keeps the user grounded in the current context.

Thin, 1px borders in neutral-variant tones are used to define boundaries on glass elements where shadows might be insufficient.

## Shapes
The shape language is "Soft Professional." A standard radius of 8px to 12px is applied across the system to soften the clinical nature of financial data.

- **Standard Containers:** 8px radius for input fields and small cards.
- **Large Sections:** 12px radius for main conversion modules and hero sections.
- **Pill Elements:** Buttons and trend indicators (chips) may use a fully rounded "pill" shape (999px) to contrast against the more structural rectangular cards.

## Components
Consistent component behavior ensures a predictable user experience:

- **Buttons:** Primary buttons are solid "Electric Blue" with white text. Ghost buttons use a 1px cool gray border. All buttons have a subtle hover transition that deepens the shadow.
- **Currency Inputs:** Large, borderless numeric inputs with a prominent currency code (e.g., USD) and flag icon. Focus states are indicated by a 2px "Electric Blue" bottom border.
- **Trend Chips:** Small pill-shaped badges using 10% opacity of secondary or tertiary accents with high-contrast text and a small directional arrow icon.
- **Glass Cards:** Used for "Recent Conversions" or "Watchlists." These feature the backdrop blur and a thin interior white stroke to catch the light.
- **Charts:** Line charts use a 1.5px stroke width. The area under the line uses a subtle gradient fade from the accent color to transparent.
- **Currency Selectors:** Full-screen or modal-based lists with large touch targets (44px min height) and alphabetical indexing for rapid searching.